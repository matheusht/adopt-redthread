# RedThread Candidate Workflow Import

- Import status: imported_as_candidate_workflows
- Candidate workflows: 1
- Blocked reason: none
- Imported as findings: No
- Severity assigned: No
- Live execution authorized: No

## candidate_workflow_001
- Source step: `step_001_001`
- Subject: `subject_001`
- Workflow type: `attack_judge_defend_validate`
- Source evidence: ev_001_001, ev_001_002, ev_001_003, ev_001_004, ev_001_005
- Expected signal: RedThread determines whether the sanitized workflow evidence is meaningful enough for JudgeAgent evaluation
- Success condition: JudgeAgent completes final evaluation; adopt-redthread makes no finding claim
- JudgeAgent required: Yes
