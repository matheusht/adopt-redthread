# RedThread Importability Report

- Importable: True
- Privacy safe: True
- Execution ready: True
- Judge required: True
- Candidate workflow created: True
- Blocked reason: none
- Evidence count: 5
- Attack step count: 1
